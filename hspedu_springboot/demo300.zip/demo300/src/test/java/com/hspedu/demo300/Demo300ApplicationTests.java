package com.hspedu.demo300;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo300ApplicationTests {

	@Test
	void contextLoads() {
	}

}
